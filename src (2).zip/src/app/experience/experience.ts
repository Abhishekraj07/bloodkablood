export interface experience
{
    feedBackId :number;
    hospitalName :string;
    city: string;
    comment :string;
    userId : number;
}