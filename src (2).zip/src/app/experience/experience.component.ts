import { Component, OnInit } from '@angular/core';
import { FeedbackService } from '../service/feedback.service';
import { experience } from './experience';

@Component({
  selector: 'app-experience',
  templateUrl: './experience.component.html',
  styleUrls: ['./experience.component.css']
})
export class ExperienceComponent implements OnInit {
  availableExperience : experience[];

  constructor(private feedback : FeedbackService) { }

  ngOnInit() {
    /*console.log("init");
    this.availableExperience=this.feedback.getAllFeedback();
    console.log(this.availableExperience);*/
  }
  onclick()
  {
    this.availableExperience=this.feedback.getAllFeedback();
  }


}
