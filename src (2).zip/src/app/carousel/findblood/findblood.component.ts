import { Component, OnInit } from '@angular/core';
import { BloodAvailablityService } from 'src/app/service/blood-availablity.service';
import { findblood } from './findblood';

@Component({
  selector: 'app-findblood',
  templateUrl: './findblood.component.html',
  styleUrls: ['./findblood.component.css']
})
export class FindbloodComponent implements OnInit {

  availableBlood : findblood[];
  constructor(private blood : BloodAvailablityService) { }

  ngOnInit() {
    /* this.availableBlood = this.blood.getAvailableBlood(); */
  }
  onclick()
  {
    console.log(this.availableBlood);
    this.availableBlood = this.blood.getAvailableBlood();
  }


}
