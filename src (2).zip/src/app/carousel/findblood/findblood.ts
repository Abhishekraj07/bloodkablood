export interface findblood
{
    availableBloodId : number;
    bloodGroup : string;
    hospitalName : string;
    state:string;
    pincode : number;
    contactNUmber : number;
    bloodUnits : number;
}