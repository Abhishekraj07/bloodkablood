import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-tab',
  templateUrl: './login-tab.component.html',
  styleUrls: ['./login-tab.component.css']
})
export class LoginTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
