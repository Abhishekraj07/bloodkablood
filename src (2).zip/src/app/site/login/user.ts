export interface user
{
    userId:number;
    userName:string;
    lastName:string;
    age:number;
    gender:string;
    contactNumber:number;
    email:string;
    password:string;
    weight:number;
    state:string;
    pincode:number;
    bloodGroup:string;
    lastDonateDate:Date;
}