import { Injectable } from '@angular/core';
import { findblood } from '../carousel/findblood/findblood';

@Injectable({
  providedIn: 'root'
})
export class BloodAvailablityService {

  availableBLood : findblood[]=[
    { availableBloodId :1,bloodGroup :"o+",hospitalName :"abc hospital",state:"andhrapradesh",  pincode : 801503, contactNUmber :999999999, bloodUnits : 23 },
    { availableBloodId :1,bloodGroup :"o+",hospitalName :"abc hospital",state:"andhrapradesh",  pincode : 801503, contactNUmber :999999999, bloodUnits : 23 }

  ]
;

  constructor() { }
  getAvailableBlood():findblood[]{
    return this.availableBLood;
  }
}
