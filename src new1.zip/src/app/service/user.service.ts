import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment.prod';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { user } from '../site/login/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl = environment.baseUrl;

  authCredentials = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Basic ' + btoa('user:pwd')
    })
  };

  constructor(private http: HttpClient) { }

  getUsers() {
    this.http.get(this.baseUrl + '/users/', this.authCredentials).subscribe((res) => console.log(res));
  }
  addUser(user: user) {
    console.log(user);
    return this.http.post<user>(this.baseUrl + '/users', user, this.authCredentials)
  }
}
