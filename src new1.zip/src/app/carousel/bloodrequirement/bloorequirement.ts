export interface bloodrequirement{
    bloodRequestId : number;
    bloodGroup : string;
    hospitalName : string;
    state : string;
    area :string;
    pincode :number;
    contactNumber : number;
    blooUnits : number;
    fulfilled : boolean;
    userId :number;
}