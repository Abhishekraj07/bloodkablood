export interface experience
{
    hospitalName :string;
    city: string;
    comment :string;
    userId : number;
}