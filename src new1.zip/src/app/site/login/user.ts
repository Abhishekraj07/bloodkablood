export interface user
{
    userName:string;
    firstName:string;
    lastName:string;
    age:number;
    gender:string;
    contactNumber:number;
    email:string;
    password:string;
    weight:number;
    state:string;
    area:number;
    pincode:number;
    bloodGroup:string

}