import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';
import { AuthenticationService } from 'src/app/service/authentication.service';
import { BloodAvailablityService } from 'src/app/service/blood-availablity.service';
import { SlotService } from 'src/app/service/slot.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:string = "";
  password:string = "";
  

  
  submitted = false;

  validCredentials = true;
  successLogin = false;

  constructor(private router: Router, private bloodAvailabilityService: BloodAvailablityService,private slotService: SlotService,private authService: AuthService, private authenticationService: AuthenticationService) { }

  ngOnInit() {
  }

  async onSubmit() {
    console.log(this.username+" "+this.password);
    this.submitted = true;

    //console.log(this.loginForm.value)

    await this.authService.authenticate(this.username, this.password).toPromise().then((res) => {
      this.successLogin = true;
      this.authService.setToken(res.token);
      this.bloodAvailabilityService.isAdmin = false;
      this.slotService.isAdmin = false;
      this.authService.loggedIn = true;
      this.bloodAvailabilityService.isLoggedIn = true;      
      this.slotService.isLoggedIn = true;
      this.authService.name = this.username;
      if (res.role === 'ROLE_ADMIN') {
        this.bloodAvailabilityService.isAdmin = true;
      } else {
        this.bloodAvailabilityService.isAdmin = false;
      }
      
      this.router.navigateByUrl('');
      this.validCredentials = true;
      this.router.navigate(['']);
    }, () => { this.successLogin = false; this.validCredentials = false; }
    );



  }

}
