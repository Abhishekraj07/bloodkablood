import { Injectable } from '@angular/core';
import { experience } from '../experience/experience';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  feedback : experience[]=[
    {feedBackId:1,hospitalName:"abc-hospital",city:"pune",comment:"It was a great experience",userId:1},
    {feedBackId:2,hospitalName:"xyz-hospital",city:"mumbai",comment:"felt good ",userId:2}
  ] 

  constructor() { }
  getAllFeedback():experience[]{
    console.log("inia")
    return this.feedback;
  }
}
