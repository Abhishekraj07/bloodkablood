import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bloodrequirement',
  templateUrl: './bloodrequirement.component.html',
  styleUrls: ['./bloodrequirement.component.css']
})
export class BloodrequirementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
