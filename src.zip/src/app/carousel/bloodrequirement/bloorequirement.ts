export interface bloodrequirement{
    bloodRequestId : number;
    blooGroup : string;
    hospitalName : string;
    state : string;
    area :string;
    pincode :number;
    contactNumber : number;
    blooUnits : number;
    fulfilled : boolean;
    userI :number;
}