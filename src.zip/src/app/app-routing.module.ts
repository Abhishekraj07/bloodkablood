import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './site/login/login.component';
import { TipsComponent } from './carousel/tips/tips.component';
import { CarouselComponent } from './carousel/carousel.component';
import { FaqComponent } from './faq/faq.component';
import { BloodAvailablityService } from './service/blood-availablity.service';
import { FindbloodComponent } from './carousel/findblood/findblood.component';
import { ExperienceComponent } from './experience/experience.component';
import { SlotComponent } from './slot/slot.component';
import { AuthGuardService } from './service/auth-guard.service';


const routes: Routes = [
{path : 'login', component : LoginComponent},
{path : 'home' , component : CarouselComponent},
{path : 'faq', component : FaqComponent},
{path : 'blood-donation' , component : FindbloodComponent },
{path : 'feedback', component : ExperienceComponent} ,
{path : 'slot' , component :SlotComponent ,canActivate: [AuthGuardService]},
{path : '' , component : CarouselComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
