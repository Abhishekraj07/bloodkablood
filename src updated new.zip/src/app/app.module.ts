import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './site/login/login.component';
import { CarouselComponent } from './carousel/carousel.component';
import { RegisterComponent } from './site/login/register/register.component';
import { ExperienceComponent } from './experience/experience.component';
import { FaqComponent } from './faq/faq.component';
import { FindbloodComponent } from './carousel/findblood/findblood.component';
import { BloodrequirementComponent } from './carousel/bloodrequirement/bloodrequirement.component';
import { MoreComponent } from './carousel/more/more.component';
import { ContactComponent } from './contact/contact.component';
import { NewPageComponent } from './new-page/new-page.component';
import { TipsComponent } from './carousel/tips/tips.component';
import { LoginTabComponent } from './site/login/login-tab/login-tab.component';
import { SlotComponent } from './slot/slot.component';
import { ShowBLoodAvailablityComponent } from './show-blood-availablity/show-blood-availablity.component';
import { HttpClientModule } from '@angular/common/http';
import { MyRequestComponent } from './my-request/my-request.component';
import { AdminComponent } from './admin/admin/admin.component';
import { AdminUnitComponent } from './admin/admin-unit/admin-unit.component';
import { BloodRequirementPostComponent } from './blood-requirement-post/blood-requirement-post.component';
import { DonorRegisterComponent } from './donor-register/donor-register.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    CarouselComponent,
    RegisterComponent,
    ExperienceComponent,
    FaqComponent,
    FindbloodComponent,
    BloodrequirementComponent,
    MoreComponent,
    ContactComponent,
    NewPageComponent,
    TipsComponent,
    LoginTabComponent,
    SlotComponent,
    ShowBLoodAvailablityComponent,
    MyRequestComponent,
    AdminComponent,
    AdminUnitComponent,
    BloodRequirementPostComponent,
    DonorRegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
