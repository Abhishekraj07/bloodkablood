import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BloodRequirementPostComponent } from './blood-requirement-post.component';

describe('BloodRequirementPostComponent', () => {
  let component: BloodRequirementPostComponent;
  let fixture: ComponentFixture<BloodRequirementPostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BloodRequirementPostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BloodRequirementPostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
