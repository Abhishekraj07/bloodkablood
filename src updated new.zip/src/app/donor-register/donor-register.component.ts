import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donor-register',
  templateUrl: './donor-register.component.html',
  styleUrls: ['./donor-register.component.css']
})
export class DonorRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
