import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { slot } from './slot';
import { SlotService } from '../service/slot.service';

@Component({
  selector: 'app-slot',
  templateUrl: './slot.component.html',
  styleUrls: ['./slot.component.css']
})
export class SlotComponent implements OnInit {
  public valid:boolean=false;
  appointmentForm: FormGroup;
  Slot :slot;

  constructor(private slotService : SlotService) { }

  ngOnInit() {
    this.appointmentForm= new FormGroup({
      HospitalName: new FormControl(),
      City: new FormControl(),
      Date: new FormControl(),
      Time: new FormControl()
    });
    

  }
  onSubmit()
  {
    console.log(this.appointmentForm);
    this.slotService.bookSlot(this.Slot).subscribe((res) => {console.log("success")});    
    return this.valid=true;
  }

}
