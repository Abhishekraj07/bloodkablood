import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';
import { slot } from '../slot/slot';
import { environment } from 'src/environments/environment.prod';

@Injectable({
  providedIn: 'root'
})
export class SlotService {

  baseUrl = environment.baseUrl;
  private subject = new Subject<slot[]>();
  Slot : slot[];
  isAdmin:boolean;
  isLoggedIn:boolean;

  userAuthCredentials = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Basic ' + btoa('user:pwd')
    })
  };

  constructor(private http: HttpClient) { }
  getSubject(): Subject<slot[]> {
    return this.subject;
  }
  bookSlot(slotBook : slot)
  {
    return this.http.post<slot>(this.baseUrl + '/slotBooking', slotBook, this.userAuthCredentials)
  }
  checkSlot(slotBook : slot)
  {
    return this.http.put<slot>(this.baseUrl + '/checkSlot', slotBook, this.userAuthCredentials)
 
  }

}
