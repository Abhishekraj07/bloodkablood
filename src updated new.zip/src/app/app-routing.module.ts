import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './site/login/login.component';
import { TipsComponent } from './carousel/tips/tips.component';
import { CarouselComponent } from './carousel/carousel.component';
import { FaqComponent } from './faq/faq.component';
import { BloodAvailablityService } from './service/blood-availablity.service';
import { FindbloodComponent } from './carousel/findblood/findblood.component';
import { ExperienceComponent } from './experience/experience.component';
import { SlotComponent } from './slot/slot.component';
import { AuthGuard } from './service/auth.guard';
import { RegisterComponent } from './site/login/register/register.component';
import { BloodrequirementComponent } from './carousel/bloodrequirement/bloodrequirement.component';
import { MyRequestComponent } from './my-request/my-request.component';
import { AdminComponent } from './admin/admin/admin.component';
import { BloodRequirementPostComponent } from './blood-requirement-post/blood-requirement-post.component';
import { DonorRegisterComponent } from './donor-register/donor-register.component';


const routes: Routes = [
{path : 'login', component : LoginComponent},
{path : 'home' , component : CarouselComponent},
{path : 'faq', component : FaqComponent},
{path : 'blood-donation' , component : FindbloodComponent, /* canActivate: [AuthGuard] */},
{path : 'feedback', component : ExperienceComponent} ,
{path : 'slot' , component :SlotComponent , /* canActivate: [AuthGuard] */},
{path : 'register' , component : RegisterComponent},
{path : 'blood-requirement', component :BloodrequirementComponent},
{path : 'my-requests', component : MyRequestComponent},
{path : 'adminanswer' ,component : AdminComponent},
{path : 'post-requirement' ,component:BloodRequirementPostComponent },
{path :'donor-register' , component :DonorRegisterComponent},
{path : '' , component : CarouselComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
