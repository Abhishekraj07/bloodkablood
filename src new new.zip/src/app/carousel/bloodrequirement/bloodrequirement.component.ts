import { Component, OnInit, ɵConsole } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { bloodrequirement } from './bloorequirement';
import { BloodRequestService } from 'src/app/service/blood-request.service';
import { user } from 'src/app/site/login/user';

@Component({
  selector: 'app-bloodrequirement',
  templateUrl: './bloodrequirement.component.html',
  styleUrls: ['./bloodrequirement.component.css']
})
export class BloodrequirementComponent implements OnInit {
  bloodrequirementForm: FormGroup;
  requiredBlood: bloodrequirement[];
  Requestor: user;


  constructor(private blood: BloodRequestService) { }

  ngOnInit() {
    this.bloodrequirementForm = new FormGroup({
      State: new FormControl(),
      Area: new FormControl(),
      Pincode: new FormControl(),
      BloodGroup: new FormControl()
    });


  }

  onclick() {
    //this.requiredBlood = this.blood.getRequiredBlood();
    console.log(this.bloodrequirementForm);
    if ((this.bloodrequirementForm.value.State != null) && (this.bloodrequirementForm.value.Area == null) &&
      (this.bloodrequirementForm.value.Pincode == null) &&
      (this.bloodrequirementForm.value.BloodGroup == null)) {
      this.getByState();
      console.log(this.getByState);
    }
    else if (
      (this.bloodrequirementForm.value.State != null) && (this.bloodrequirementForm.value.Area != null) &&
      (this.bloodrequirementForm.value.Pincode == null) &&
      (this.bloodrequirementForm.value.BloodGroup == null)
    ) {
      this.getByStateAndArea();
       

    }
    else if (
      (this.bloodrequirementForm.value.State == null) && (this.bloodrequirementForm.value.Area == null) &&
      (this.bloodrequirementForm.value.Pincode == null) &&
      (this.bloodrequirementForm.value.BloodGroup != null)
    ) {
      this.getByBLoodGroup();
    }
    else if (
      (this.bloodrequirementForm.value.State != null) && (this.bloodrequirementForm.value.Area != null) &&
      (this.bloodrequirementForm.value.Pincode != null) &&
      (this.bloodrequirementForm.value.BloodGroup != null)
    ) {
      this.getByAll();
    }
    else {
      console.log("please select valid option");
    }


  }

  getByAll() {
    this.blood.getBLoodRequestForParticularLocation(this.bloodrequirementForm.value.State,
      this.bloodrequirementForm.value.Area,
      this.bloodrequirementForm.value.Pincode,
      this.bloodrequirementForm.value.BloodGroup).subscribe((res) => this.requiredBlood = res);
    this.blood.getSubject().subscribe((data) => {
      this.requiredBlood = data;
    });
  }
  getByState() {
    this.blood.getBloodRequestForState(this.bloodrequirementForm.value.State).subscribe((res) => this.requiredBlood = res);
    this.blood.getSubject().subscribe((data) => {
      this.requiredBlood = data;
    });
  }
  getByStateAndArea() {
    this.blood.getBloodRequestForStateAndArea(this.bloodrequirementForm.value.State,
      this.bloodrequirementForm.value.Area).subscribe((res) => this.requiredBlood = res);
    this.blood.getSubject().subscribe((data) => {
      this.requiredBlood = data;
    });
  }
  getByBLoodGroup() {
    this.blood.getBLoodRequestForBloodGroup(this.bloodrequirementForm.value.BloodGroup).subscribe((res) => this.requiredBlood = res);
    this.blood.getSubject().subscribe((data) => {
      this.requiredBlood = data;
    });


  }







}
