import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { user } from '../user';
import { UserService } from 'src/app/service/user.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
registerForm: FormGroup;
user: user;
  constructor(private userService:UserService) { }

  ngOnInit() {
    this.registerForm=new FormGroup({
      Username:new FormControl(),
      FirstName:new FormControl(),
      LastName:new FormControl(),
      Age:new FormControl(),
      Gender:new FormControl(),
      Contactnumber:new FormControl(),
      Email:new FormControl(),
      Weight:new FormControl(),
      Pincode:new FormControl(),
      State:new FormControl(),
      Area:new FormControl(),
      BloodGroup:new FormControl(),
      Password:new FormControl(),
      ConfirmPassword:new FormControl()
    });
  }
  onSubmit()
  {
    if(this.registerForm.value.Password==this.registerForm.value.ConfirmPassword)
    {
     this.user= {
      userId:null,
      userName:this.registerForm.value.Username,
      firstName:this.registerForm.value.FirstName,
      lastName:this.registerForm.value.LastName,
      age:this.registerForm.value.Age,
      gender:this.registerForm.value.Gender,
      contactNumber:this.registerForm.value.Contactnumber,
      email:this.registerForm.value.Email,
      password:this.registerForm.value.Password,
      weight:this.registerForm.value.Weight,
      pincode:this.registerForm.value.Pincode,
      state:this.registerForm.value.State,
      area:this.registerForm.value.Area,
      bloodGroup:this.registerForm.value.BloodGroup

     }

      this.userService.addUser(this.user).subscribe((res)=>{console.log("SUCCESS")});
      console.log(this.user);

    }
    else{
      console.log("password doesnot matched");
    }
  }

}
