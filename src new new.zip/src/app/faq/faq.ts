export interface faq
{
   faqId:number;
    question:string;
    answer:string;
    userId:number;
}