import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-unit',
  templateUrl: './admin-unit.component.html',
  styleUrls: ['./admin-unit.component.css']
})
export class AdminUnitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
