import { Injectable } from '@angular/core';
import { findblood } from '../carousel/findblood/findblood';
import { environment } from 'src/environments/environment.prod';
import { Subject, Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BloodAvailablityService {

  baseUrl = environment.baseUrl;
  private subject = new Subject<findblood[]>();
  isAdmin = false;
  isLoggedIn = false;
  availableBLood: findblood[];

  userAuthCredentials = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Basic ' + btoa('user:pwd')
    })
  };

  constructor(private http: HttpClient) { }
  getAvailableBlood():Observable<findblood[]>{
    //return this.availableBLood;
    return this.http.get<findblood[]>(this.baseUrl + '/availableblood', this.userAuthCredentials)
  }

  getSubject(): Subject<findblood[]> {
    return this.subject;
  }

}
