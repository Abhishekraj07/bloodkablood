import { Component, OnInit } from '@angular/core';
import { MyRequestService } from '../service/my-request.service';
import { MyRequest } from './myRequest';
import { UserService } from '../service/user.service';
import { AuthService } from '../service/auth.service';
import { user } from '../site/login/user';

@Component({
  selector: 'app-my-request',
  templateUrl: './my-request.component.html',
  styleUrls: ['./my-request.component.css']
})
export class MyRequestComponent implements OnInit {

  myRequests: MyRequest[];
  userName:string;
  user:user;
  userId:number;
  constructor(private myRequestService: MyRequestService,private authService:AuthService, private userService:UserService) {
    
   }

  ngOnInit() {
    this.userService.getUser(this.userName).subscribe( (res)=> {this.user = res;
      console.log("user:"+this.user)});
    this.userService.getSubject().subscribe((data) => {
      this.user = data;
    });
    this.userId = 2;
    this.myRequestService.getMyRequests(this.userId).subscribe((res) => this.myRequests = res);
      this.myRequestService.getSubject().subscribe((data) => {
        this.myRequests = data;
      });
  }

  getMyRequests(){
    this.userId = this.authService.loggedInUser.userId;
    this.myRequestService.getMyRequests(this.userId).subscribe((res) => this.myRequests = res);
      this.myRequestService.getSubject().subscribe((data) => {
        this.myRequests = data;
      });

  }

}
