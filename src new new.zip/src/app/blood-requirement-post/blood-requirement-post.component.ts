import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BloodRequestService } from '../service/blood-request.service';
import { bloodrequirement } from '../carousel/bloodrequirement/bloorequirement';
import { Subject, Observable } from 'rxjs';

@Component({
  selector: 'app-blood-requirement-post',
  templateUrl: './blood-requirement-post.component.html',
  styleUrls: ['./blood-requirement-post.component.css']
})
export class BloodRequirementPostComponent implements OnInit {

  
  issumitted: boolean = false;
  success: boolean = false;
  findbloodrequirementForm: FormGroup;
  bloodRequirement : bloodrequirement;

  constructor(private formBuilder: FormBuilder,private blood: BloodRequestService) { }

  ngOnInit() {
    this.findbloodrequirementForm = this.formBuilder.group({
      State: new FormControl('', [Validators.required]),
      Area: new FormControl('', [Validators.required]),
      Pincode: new FormControl('', [Validators.required, Validators.minLength(6)]),
      BloodGroup: new FormControl('', [Validators.required]),
    });
  }
  OnSubmit() {
    this.issumitted = true;

    if (this.findbloodrequirementForm.invalid) {
      return;
    }

    this.success = true;

    console.log(this.issumitted);
    this.bloodRequirement={
      contactNumber:1234567890,
      state:this.findbloodrequirementForm.value.State,
      area :this.findbloodrequirementForm.value.Area,
      pincode :this.findbloodrequirementForm.value.Pincode,
      bloodGroup:this.findbloodrequirementForm.value.BloodGroup,
      userId:6,
      firstName:"",
      lastName:"",
      bloodRequestId:1,
      requestedDate:null
    }
    this.blood.postBloodRequest(this.bloodRequirement).subscribe((res)=>{console.log("SUCCESS")});

  }

  get f() {
    return this.findbloodrequirementForm.controls;
  }


}
