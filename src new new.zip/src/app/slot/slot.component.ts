import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-slot',
  templateUrl: './slot.component.html',
  styleUrls: ['./slot.component.css']
})
export class SlotComponent implements OnInit {
  public valid:boolean=false;
  appointmentForm: FormGroup;

  constructor() { }

  ngOnInit() {
    this.appointmentForm= new FormGroup({
      HospitalName: new FormControl(),
      City: new FormControl(),
      Date: new FormControl(),
      Time: new FormControl()
    });
    

  }
  onSubmit()
  {
    return this.valid=true;
    console.log(this.appointmentForm)
  }


}
